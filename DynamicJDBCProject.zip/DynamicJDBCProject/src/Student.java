
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(description = "Student data", urlPatterns = { "/saveStudent" })
public class Student extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String sname=request.getParameter("sname");
		String scourse=request.getParameter("scourse");
		String sphone=request.getParameter("sphone");
		
		
		String sql="insert into student(name,course,phone) values('"+sname+"','"+scourse+"',"+sphone+")";
		
		System.out.println(sql);
		
		DBConfig.executeUpdate(sql);
		
		PrintWriter pw=response.getWriter();
		
		pw.println("<html>");
			pw.println("<body>");
				pw.println("<table>");
					pw.println("<tr>");
						pw.println("<td>ID</td>");
						pw.println("<td>NAME</td>");
						pw.println("<td>COURSE</td>");
						pw.println("<td>PHONE</td>");
					pw.println("</tr>");
					
					ResultSet rs=DBConfig.executeQuery("SELECT * FROM STUDENT");
					try {
						while(rs.next())
						{
							pw.println("<tr>");
							pw.println("<td>"+rs.getInt("id")+"</td>");
							pw.println("<td>"+rs.getString("name")+"</td>");
							pw.println("<td>"+rs.getString("course")+"</td>");
							pw.println("<td>"+rs.getString("phone")+"</td>");
							pw.println("</tr>");
						
						}
					}
					catch(Exception ex)
					{
						pw.println("<tr>");
						pw.println("<td>No Data</td>");
						pw.println("<td>No Data</td>");
						pw.println("<td>No Data</td>");
						pw.println("<td>No Data</td>");
						pw.println("</tr>");
					
						ex.printStackTrace();
					}
					
				pw.println("</table>");
			pw.println("</body>");
		pw.println("</html>");
	}

}
