import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DBConfig {
	// VALUES THAT CAN BE CHANGE
	private static final String DBDRIVER = "org.h2.Driver";
	private static final String DBURL = "jdbc:h2:tcp://localhost/~/jdbctest";
	private static final String DBUSERNAME = "sa";
	private static final String DBPASSWORD = "123";
	// VALUES THAT CAN NOT BE CHANGE
	// CODE NOT TO CHANGE
	private static Statement stmt = null;

	private static void openConnection() {
		try {
			Class.forName(DBDRIVER);
			Connection conn = DriverManager.getConnection(DBURL, DBUSERNAME, DBPASSWORD);
			stmt = conn.createStatement();
		} catch (Exception ex) {
			ex.printStackTrace();

		}
	}

	// to excute ddl,dml,dcl sql query
	public static int executeUpdate(String sql) {
		try {
			openConnection();
			return stmt.executeUpdate(sql);
		} catch (Exception ex) {
			ex.printStackTrace();
			return -1;
		}

	}

	// to execute select query
	public static ResultSet executeQuery(String sql)
	{
		try
		{
		openConnection();
		return stmt.executeQuery(sql);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			return null;
		}

	}
}
